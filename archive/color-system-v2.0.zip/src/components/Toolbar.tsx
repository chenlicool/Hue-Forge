import React from 'react';
import { Download, RefreshCw } from 'lucide-react';

interface ToolbarProps {
  onSetPresetHues: (count: number) => void;
  onCopySvg: () => void;
  onClearAll?: () => void; // Optional: if we want to add a clear all button later
}

export function Toolbar({ onSetPresetHues, onCopySvg }: ToolbarProps) {
  return (
    <div className="flex items-center justify-between px-8 py-4 bg-white border-b border-gray-200">
      
      {/* Left: Palette Generators */}
      <div className="flex items-center gap-4">
        <span className="text-sm font-medium text-gray-500">Auto-Generate:</span>
        <div className="flex bg-gray-100 p-1 rounded-lg">
          {[8, 12, 24].map((count) => (
            <button
              key={count}
              onClick={() => onSetPresetHues(count)}
              className="px-3 py-1.5 text-sm font-medium text-gray-700 hover:text-gray-900 hover:bg-white rounded-md transition-all focus:outline-none focus:ring-2 focus:ring-gray-200"
            >
              {count} Hues
            </button>
          ))}
        </div>
      </div>

      {/* Right: Actions */}
      <div className="flex items-center gap-3">
        <button
          onClick={onCopySvg}
          className="flex items-center gap-2 px-4 py-2 bg-gray-900 text-white text-sm font-medium rounded-lg hover:bg-gray-800 transition-colors shadow-sm"
        >
          <Download className="w-4 h-4" />
          Export SVG
        </button>
      </div>
    </div>
  );
}
