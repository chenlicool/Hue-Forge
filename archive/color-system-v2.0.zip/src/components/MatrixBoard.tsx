import React, { useState, useEffect } from 'react';
import { cn } from '@/utils/cn';
import { ColorStep, HueConfig } from '@/utils/types';
import { hsbToHex } from '@/utils/color';
import { Trash2, Plus } from 'lucide-react';

interface BaseScaleInputProps {
  brightness: number;
  textColor: string;
  onChange: (val: number) => void;
}

function BaseScaleInput({ brightness, textColor, onChange }: BaseScaleInputProps) {
  const [localValue, setLocalValue] = useState(brightness.toString());

  useEffect(() => {
    setLocalValue(brightness.toString());
  }, [brightness]);

  return (
    <input
      type="number"
      min="0"
      max="100"
      value={localValue}
      onChange={(e) => {
        setLocalValue(e.target.value);
        const val = parseInt(e.target.value);
        if (!isNaN(val)) {
          onChange(val);
        }
      }}
      onBlur={() => {
        if (localValue === '' || isNaN(parseInt(localValue))) {
          setLocalValue(brightness.toString());
        }
      }}
      className="w-full bg-transparent text-sm font-bold text-center focus:outline-none"
      style={{ color: textColor }}
    />
  );
}

interface MatrixBoardProps {
  palettes: (HueConfig & { colors: ColorStep[] })[];
  selectedHueId: string | null;
  onSelectHue: (id: string) => void;
  onColorClick: (hueId: string, stepIndex: number) => void;
  activeStepIndex: number | null;
  onRemoveHue: (id: string) => void;
  
  // Base Scale Props
  baseScale: number[];
  onAddStep: (index: number) => void;
  onRemoveStep: (index: number) => void;
  onUpdateStepValue: (index: number, value: number) => void;
  onUpdateHueName: (id: string, name: string) => void;
}

export function MatrixBoard({ 
  palettes, 
  selectedHueId, 
  onSelectHue, 
  onColorClick, 
  activeStepIndex, 
  onRemoveHue,
  baseScale,
  onAddStep,
  onRemoveStep,
  onUpdateStepValue,
  onUpdateHueName
}: MatrixBoardProps) {

  const containerRef = React.useRef<HTMLDivElement>(null);
  const selectedColRef = React.useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (selectedColRef.current && containerRef.current) {
      const container = containerRef.current;
      const col = selectedColRef.current;
      
      const containerRect = container.getBoundingClientRect();
      const colRect = col.getBoundingClientRect();
      
      // Check if column is out of view
      if (colRect.left < containerRect.left + 96 || colRect.right > containerRect.right) {
        // Scroll to center the column
        const scrollLeft = col.offsetLeft - containerRect.width / 2 + colRect.width / 2;
        container.scrollTo({ left: scrollLeft, behavior: 'smooth' });
      }
    }
  }, [selectedHueId]);

  return (
    <div ref={containerRef} className="flex-1 bg-[#F5F5F5] overflow-auto relative">
      <div className="flex min-w-max min-h-full">
      
        {/* Module 1: Base Scale (Fixed Left) */}
        <div className="w-24 shrink-0 bg-white border-r border-gray-200 flex flex-col sticky left-0 z-30 shadow-[4px_0_24px_rgba(0,0,0,0.02)]">
          <div className="h-16 flex items-center justify-center border-b border-gray-100 bg-gray-50 sticky top-0 z-40">
            <span className="text-xs font-medium text-gray-500 uppercase tracking-wider text-center leading-tight">Base<br/>Scale</span>
          </div>
          <div className="flex-1 flex flex-col py-4 gap-4 px-4">
            {baseScale.map((brightness, i) => {
              const isLight = brightness > 50;
              const textColor = isLight ? 'black' : 'white';
              
              return (
                <div 
                  key={`base-${i}`}
                  className="flex-1 w-full rounded shadow-sm relative group hover:scale-105 transition-transform duration-200 min-h-[3rem]"
                  style={{ backgroundColor: hsbToHex(0, 0, brightness) }}
                >
                   <div className="absolute inset-0 flex items-center justify-center">
                     <div className="flex flex-col items-center">
                       <BaseScaleInput
                           brightness={brightness}
                           textColor={textColor}
                           onChange={(val) => onUpdateStepValue(i, val)}
                       />
                       <span className="text-[9px] opacity-60 uppercase" style={{ color: textColor }}>Brightness</span>
                     </div>
                   </div>

                   {/* Delete Step Button */}
                   <button
                       onClick={() => onRemoveStep(i)}
                       className="absolute -right-2 -top-2 p-1 bg-white rounded-full shadow-md text-gray-500 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity z-10"
                       title="Remove step"
                   >
                       <Trash2 className="w-3 h-3" />
                   </button>
                </div>
              );
            })}

            {/* Add Step Button */}
            <button
                onClick={() => onAddStep(baseScale.length)}
                className="h-8 shrink-0 flex items-center justify-center rounded border border-dashed border-gray-300 text-gray-400 hover:border-gray-400 hover:text-gray-600 hover:bg-gray-50 transition-all"
                title="Add new step"
            >
                <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Module 2 & 3: Palettes */}
        {palettes.filter(p => p.id === 'gray' || p.id === 'accent-gray').map((palette, idx, arr) => {
          const isLastGray = idx === arr.length - 1;
          return (
            <div 
              key={palette.id} 
              ref={selectedHueId === palette.id ? selectedColRef : null}
              className={cn(
                "flex flex-col w-32 shrink-0 border-r transition-colors bg-white",
                selectedHueId === palette.id ? "bg-blue-50/30" : "bg-white",
                isLastGray ? "border-r-4 border-gray-200" : "border-gray-100"
              )}
              onClick={() => onSelectHue(palette.id)}
            >
              {/* Column Header */}
              <div className="h-16 flex items-center justify-center border-b border-gray-100 relative group/header bg-white sticky top-0 z-20">
                <input
                  type="text"
                  value={palette.name}
                  onChange={(e) => onUpdateHueName(palette.id, e.target.value)}
                  className={cn(
                    "text-sm font-medium bg-transparent text-center w-full focus:outline-none px-2",
                    selectedHueId === palette.id ? "text-gray-900" : "text-gray-500"
                  )}
                />
                
                {/* Delete Button */}
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    onRemoveHue(palette.id);
                  }}
                  className="absolute top-2 right-2 p-1.5 text-gray-400 hover:text-red-500 rounded opacity-0 group-hover/header:opacity-100 transition-all"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Color Blocks */}
              <div className="flex-1 flex flex-col py-4 gap-4 px-4">
                {palette.colors.map((color, index) => {
                  const isActive = selectedHueId === palette.id && activeStepIndex === index;
                  
                  // Determine best text color based on contrast
                  const textColor = color.contrastBlack >= color.contrastWhite ? 'black' : 'white';
                  const contrast = color.contrastBlack >= color.contrastWhite ? color.contrastBlack : color.contrastWhite;
                  const wcag = color.contrastBlack >= color.contrastWhite ? color.wcagBlack : color.wcagWhite;

                  return (
                    <div
                      key={color.step}
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectHue(palette.id);
                        onColorClick(palette.id, index);
                      }}
                      className={cn(
                        "flex-1 w-full rounded shadow-sm cursor-pointer transition-transform duration-200 relative group min-h-[3rem]",
                        isActive ? "ring-2 ring-blue-500 scale-105 z-10" : "hover:scale-105 hover:shadow-md"
                      )}
                      style={{ backgroundColor: color.hex, color: textColor }}
                    >
                      <div className="flex flex-col justify-between h-full p-2 text-[10px] font-medium leading-tight">
                        <div className="flex justify-between items-start">
                          <span className="font-bold text-xs opacity-90">{color.step}</span>
                          <span className="font-bold opacity-90">{wcag}</span>
                        </div>
                        <div className="flex justify-between items-end opacity-75">
                          <span>B:{Math.round(color.b)}</span>
                          <span>{contrast.toFixed(2)}:1</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
                
                {/* Spacer to align with Base Scale's Add Button */}
                <div className="h-8 shrink-0" />
              </div>
            </div>
          );
        })}

        {palettes
          .filter(p => p.id !== 'gray' && p.id !== 'accent-gray')
          .sort((a, b) => a.hue - b.hue)
          .map((palette) => (
          <div 
            key={palette.id} 
            ref={selectedHueId === palette.id ? selectedColRef : null}
            className={cn(
              "flex flex-col w-32 shrink-0 border-r border-gray-100 transition-colors bg-white",
              selectedHueId === palette.id ? "bg-blue-50/30" : "bg-white"
            )}
            onClick={() => onSelectHue(palette.id)}
          >
            {/* Column Header */}
            <div className="h-16 flex items-center justify-center border-b border-gray-100 relative group/header bg-white sticky top-0 z-20">
              <input
                type="text"
                value={palette.name}
                onChange={(e) => onUpdateHueName(palette.id, e.target.value)}
                className={cn(
                  "text-sm font-medium bg-transparent text-center w-full focus:outline-none px-2",
                  selectedHueId === palette.id ? "text-gray-900" : "text-gray-500"
                )}
              />
              
              {/* Delete Button */}
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  onRemoveHue(palette.id);
                }}
                className="absolute top-2 right-2 p-1.5 text-gray-400 hover:text-red-500 rounded opacity-0 group-hover/header:opacity-100 transition-all"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Color Blocks */}
            <div className="flex-1 flex flex-col py-4 gap-4 px-4">
              {palette.colors.map((color, index) => {
                const isActive = selectedHueId === palette.id && activeStepIndex === index;
                
                // Determine best text color based on contrast
                const textColor = color.contrastBlack >= color.contrastWhite ? 'black' : 'white';
                const contrast = color.contrastBlack >= color.contrastWhite ? color.contrastBlack : color.contrastWhite;
                const wcag = color.contrastBlack >= color.contrastWhite ? color.wcagBlack : color.wcagWhite;

                return (
                  <div
                    key={color.step}
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectHue(palette.id);
                      onColorClick(palette.id, index);
                    }}
                    className={cn(
                      "flex-1 w-full rounded shadow-sm cursor-pointer transition-transform duration-200 relative group min-h-[3rem]",
                      isActive ? "ring-2 ring-blue-500 scale-105 z-10" : "hover:scale-105 hover:shadow-md"
                    )}
                    style={{ backgroundColor: color.hex, color: textColor }}
                  >
                    <div className="flex flex-col justify-between h-full p-2 text-[10px] font-medium leading-tight">
                      <div className="flex justify-between items-start">
                        <span className="font-bold text-xs opacity-90">{color.step}</span>
                        <span className="font-bold opacity-90">{wcag}</span>
                      </div>
                      <div className="flex justify-between items-end opacity-75">
                        <span>B:{Math.round(color.b)}</span>
                        <span>{contrast.toFixed(2)}:1</span>
                      </div>
                    </div>
                  </div>
                );
              })}
              
              {/* Spacer to align with Base Scale's Add Button */}
              <div className="h-8 shrink-0" />
            </div>
          </div>
        ))}

        {/* Empty State / Add Placeholder */}
        {palettes.length === 0 && (
            <div className="w-64 flex items-center justify-center text-gray-400 text-sm">
                Add colors from the spectrum above
            </div>
        )}
      </div>
    </div>
  );
}
