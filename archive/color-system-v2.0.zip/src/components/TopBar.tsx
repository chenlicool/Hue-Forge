import React from 'react';
import { Copy, Download } from 'lucide-react';

interface TopBarProps {
  onCopySvg: () => void;
}

export function TopBar({ onCopySvg }: TopBarProps) {
  return (
    <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 sticky top-0 z-50">
      <div className="flex items-center gap-3">
        <h1 className="text-gray-900 font-medium text-lg tracking-tight">设计系统</h1>
      </div>

      <div className="flex items-center gap-4">
        <button 
          onClick={onCopySvg}
          className="text-gray-900 hover:text-gray-600 text-sm font-medium transition-colors"
        >
          从SVG拷贝到Figma
        </button>
        <button 
          className="text-gray-900 hover:text-gray-600 text-sm font-medium transition-colors"
        >
          下载SVG
        </button>
      </div>
    </header>
  );
}
