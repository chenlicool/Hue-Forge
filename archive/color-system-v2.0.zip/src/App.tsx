import React, { useState } from 'react';
import { useColorSystem } from '@/hooks/useColorSystem';
import { TopBar } from '@/components/TopBar';
import { HueBar } from '@/components/HueBar';
import { MatrixBoard } from '@/components/MatrixBoard';
import { InsightPanel } from '@/components/InsightPanel';
import { Toolbar } from '@/components/Toolbar';
import { hsbToHex } from '@/utils/color';

export default function App() {
  const {
    hueConfigs,
    selectedHueId,
    setSelectedHueId,
    generatePalette,
    addHue,
    removeHue,
    updateHueConfig,
    updateCurvePoint,
    setPresetHues,
    baseScale,
    addStep,
    removeStep,
    updateStepValue
  } = useColorSystem();

  const [activeStepIndex, setActiveStepIndex] = useState<number | null>(null);

  const palettes = generatePalette;
  const selectedPalette = palettes.find(p => p.id === selectedHueId);

  const handleCopySvg = () => {
    const width = (palettes.length + 1) * 120;
    const height = baseScale.length * 100 + 200;
    
    const svgContent = `
      <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
        <style>
          text { font-family: sans-serif; }
        </style>
        
        ${palettes.map((palette, i) => {
          const x = i * 120;
          return `
            <g transform="translate(${x}, 0)">
              <text x="0" y="40" font-size="14" font-weight="bold" fill="#333">${palette.name}</text>
              ${palette.colors.map((color, j) => `
                <rect x="0" y="${j * 100 + 60}" width="100" height="100" fill="${color.hex}" rx="8" />
                <text x="10" y="${j * 100 + 140}" font-size="12" fill="${color.step >= 50 ? '#fff' : '#000'}">${color.hex}</text>
              `).join('')}
            </g>
          `;
        }).join('')}

        <!-- Base Column (Right Side) -->
        <g transform="translate(${palettes.length * 120}, 0)">
          <text x="10" y="40" font-size="14" font-weight="bold" fill="#333">Base</text>
          ${baseScale.map((b, j) => `
            <rect x="0" y="${j * 100 + 60}" width="100" height="100" fill="${hsbToHex(0, 0, b)}" rx="8" />
            <text x="10" y="${j * 100 + 140}" font-size="12" fill="${b > 50 ? '#000' : '#fff'}">${b}%</text>
          `).join('')}
        </g>
      </svg>
    `;
    
    navigator.clipboard.writeText(svgContent).then(() => {
      alert('SVG copied to clipboard! Paste into Figma.');
    });
  };

  return (
    <div className="flex flex-col h-screen bg-[#F5F5F5] text-gray-900 font-sans overflow-hidden">
      {/* 1. Branding Header */}
      <TopBar onCopySvg={() => {}} /> 
      
      {/* 2. Action Toolbar */}
      <Toolbar 
        onSetPresetHues={setPresetHues} 
        onCopySvg={handleCopySvg} 
      />

      {/* 3. Hue Spectrum Input */}
      <div className="bg-white border-b border-gray-200 px-8 py-4 z-10">
        <HueBar 
          hueConfigs={hueConfigs}
          selectedHueId={selectedHueId}
          onSelectHue={setSelectedHueId}
          onUpdateHue={(id, hue) => updateHueConfig(id, { hue })}
          onAddHue={addHue}
        />
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* 4. Main Matrix Output */}
        <MatrixBoard 
          palettes={palettes}
          selectedHueId={selectedHueId}
          onSelectHue={setSelectedHueId}
          onColorClick={(hueId, index) => setActiveStepIndex(index)}
          activeStepIndex={activeStepIndex}
          onRemoveHue={removeHue}
          baseScale={baseScale}
          onAddStep={addStep}
          onRemoveStep={removeStep}
          onUpdateStepValue={updateStepValue}
          onUpdateHueName={(id, name) => updateHueConfig(id, { name })}
        />
        
        {/* 5. Details Panel */}
        {selectedHueId && (
          <InsightPanel 
            palettes={palettes}
            selectedPalette={selectedPalette}
            activeStepIndex={activeStepIndex}
            onUpdateCurve={(type, index, value) => {
              if (selectedHueId) {
                updateCurvePoint(selectedHueId, type, index, value);
              }
            }}
          />
        )}
      </div>
    </div>
  );
}
